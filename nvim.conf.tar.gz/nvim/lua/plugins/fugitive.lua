return {
	{ "tpope/vim-fugitive" },
}
